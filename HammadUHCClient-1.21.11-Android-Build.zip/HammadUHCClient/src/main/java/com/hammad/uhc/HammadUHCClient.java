package com.hammad.uhc;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

public class HammadUHCClient implements ClientModInitializer {
    public static boolean autoHead = false;
    public static boolean autoWeb = false;
    public static boolean autoLava = false;
    private static KeyMapping openGui;
    private static int actionDelay = 0;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                ResourceLocation.fromNamespaceAndPath("hammaduhc", "main"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.hammaduhc.open_gui", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.consumeClick()) {
                if (client.screen == null) client.setScreen(new HammadClickGui());
            }
            if (client.player == null || client.level == null || client.screen != null) return;
            if (actionDelay > 0) actionDelay--;
            if (actionDelay == 0) runModules(client);
        });
    }

    private static void runModules(Minecraft mc) {
        if (autoHead && mc.player.getHealth() <= 8.0f) {
            int slot = findHeadSlot(mc.player);
            if (slot >= 0) {
                int old = mc.player.getInventory().selected;
                mc.player.getInventory().selected = slot;
                mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                mc.player.getInventory().selected = old;
                actionDelay = 8;
                return;
            }
        }

        if ((autoWeb || autoLava) && mc.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit
                && hit.getEntity() instanceof Player target && target != mc.player
                && mc.player.distanceTo(target) <= 4.0f) {
            int wanted = autoWeb ? findItemSlot(mc.player, Items.COBWEB)
                                 : findItemSlot(mc.player, Items.LAVA_BUCKET);
            if (wanted >= 0) {
                int old = mc.player.getInventory().selected;
                mc.player.getInventory().selected = wanted;
                BlockPos support = BlockPos.containing(target.getX(), target.getY() - 1.0, target.getZ());
                Vec3 hitPos = Vec3.atCenterOf(support).add(0.0, 0.5, 0.0);
                BlockHitResult blockHit = new BlockHitResult(hitPos, Direction.UP, support, false);
                mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, blockHit);
                mc.player.getInventory().selected = old;
                actionDelay = 8;
            }
        }
    }

    private static int findHeadSlot(Player player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            String name = stack.getHoverName().getString().toLowerCase();
            if (!stack.isEmpty() && (name.contains("golden head") || name.contains("head"))) return i;
        }
        return findItemSlot(player, Items.GOLDEN_APPLE);
    }

    private static int findItemSlot(Player player, net.minecraft.world.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getItem(i).is(item)) return i;
        }
        return -1;
    }
}
