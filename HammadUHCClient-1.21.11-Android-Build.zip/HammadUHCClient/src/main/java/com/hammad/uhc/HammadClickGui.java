package com.hammad.uhc;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class HammadClickGui extends Screen {
    private static final int GREEN = 0xFF55FF55;
    private static final int DARK = 0xDD101810;

    public HammadClickGui() {
        super(Component.literal("Hammad UHC Client"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - 100;
        int top = this.height / 2 - 65;
        addRenderableWidget(Button.builder(label("Auto Head", HammadUHCClient.autoHead), b -> {
            HammadUHCClient.autoHead = !HammadUHCClient.autoHead;
            b.setMessage(label("Auto Head", HammadUHCClient.autoHead));
        }).bounds(left, top, 200, 20).build());
        addRenderableWidget(Button.builder(label("Auto Web", HammadUHCClient.autoWeb), b -> {
            HammadUHCClient.autoWeb = !HammadUHCClient.autoWeb;
            b.setMessage(label("Auto Web", HammadUHCClient.autoWeb));
        }).bounds(left, top + 25, 200, 20).build());
        addRenderableWidget(Button.builder(label("Auto Lava", HammadUHCClient.autoLava), b -> {
            HammadUHCClient.autoLava = !HammadUHCClient.autoLava;
            b.setMessage(label("Auto Lava", HammadUHCClient.autoLava));
        }).bounds(left, top + 50, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left, top + 80, 200, 20).build());
    }

    private static Component label(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int left = this.width / 2 - 112;
        int top = this.height / 2 - 92;
        graphics.fill(left, top, left + 224, top + 154, DARK);
        graphics.drawCenteredString(font, "HAMMAD UHC CLIENT", width / 2, top + 8, GREEN);
        graphics.drawCenteredString(font, "Right Shift - Toggle GUI", width / 2, top + 137, 0xFFFFFFFF);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
