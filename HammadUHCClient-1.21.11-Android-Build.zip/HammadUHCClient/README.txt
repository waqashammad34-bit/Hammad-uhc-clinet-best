HAMMAD UHC CLIENT — Minecraft Java 1.21.11 / Fabric

Features
- Right Shift opens the click GUI.
- Auto Head: when health is at or below 4 hearts, tries to use a hotbar item whose name contains "head"; otherwise uses a Golden Apple.
- Auto Web: when your crosshair is on another player within 4 blocks, tries to use a Cobweb from the hotbar.
- Auto Lava: same target condition, tries to use a Lava Bucket from the hotbar.
- Each module has its own ON/OFF toggle.

IMPORTANT NOTES
- This is a source project, not a precompiled .jar. Build it with Gradle on a computer, or use an Android Java/Gradle environment that supports Fabric Loom.
- Minecraft 1.21.11 uses Java 21. The runtime used by MojoLauncher must be Java 21.
- The automation is client-side and server rules/anti-cheat may block it. Use only where allowed.
- Auto Web and Auto Lava currently trigger the held-item use action while your crosshair is on a nearby player; they do not guarantee a successful block placement on every server or situation.
- Auto Head detection depends on the custom Golden Head item's displayed name. If your server uses a different name, the matching text in HammadUHCClient.java must be changed.

BUILD
1. Install JDK 21 and Gradle 8.14+ on a computer.
2. Open this project folder in a Gradle-compatible IDE or terminal.
3. Run: gradle build
4. The remapped mod jar will be in build/libs/.
5. Put the jar in the Minecraft instance's mods folder alongside Fabric API.
